﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace TABAS_REST.Models
{
    [DataContract]
    public class USER_INFO
    {
        [DataMember(Name = CONSTANTS.STARTS_AIRPORT_CODE)]
    }
}
